package la.com.jdbbank.service.jdbaccountservice.config;

public class ClientConfiguration {

}
